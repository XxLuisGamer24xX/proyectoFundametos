<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro Exitoso</title>
  <link rel="stylesheet" href="../css/tablaRegistro.css">
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener datos del formulario
        $nombre = $_POST["Nombre"];
        $correo = $_POST["correo"];
        $contrasena = $_POST["contraseña"];
        $atributo = $_POST["Atributo"];
        $genero = $_POST["genero"];
        $fechaNac = $_POST["fechaNac"];
        $carreraUniversitaria = $_POST["carreraUniversitaria"];

        // Mostrar mensaje de registro exitoso
        
        echo "<center><h1>Registro Exitoso</h1></center>";
        // Mostrar datos en una tabla
        echo "<table border='1'>";
        echo "<tr><td>Nombre Usuario</td><td>$nombre</td></tr>";
        echo "<tr><td>Correo Electrónico</td><td>$correo</td></tr>";
        echo "<tr><td>Contraseña</td><td>$contrasena</td></tr>";
        echo "<tr><td>Atributo</td><td>$atributo</td></tr>";
        echo "<tr><td>Género</td><td>$genero</td></tr>";
        echo "<tr><td>Fecha de Nacimiento</td><td>$fechaNac</td></tr>";
        echo "<tr><td>Carrera Universitaria</td><td>$carreraUniversitaria</td></tr>";
        echo "</table>";
    } else {
        echo "<h1>Error en el envío de datos</h1>";
    }
    ?>
    <center>
        <a href="../register.html">Regresar al formulario</a>
    </center>
</body>
</html>
